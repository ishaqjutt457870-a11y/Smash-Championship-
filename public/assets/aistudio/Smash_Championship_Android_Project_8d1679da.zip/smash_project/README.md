# Smash Championship (Android project)

This is an Android Studio project for a local badminton league tournament app.

## Features
- Register 4 or more players
- Round-robin league: every player plays every other player once
- Automatic league table (win = 2 points, loss = 0)
- Top 4 qualify for semi-finals (1st vs 4th, 2nd vs 3rd)
- Grand final and champion display
- Undo match results
- Tournament data saved locally on the device using browser local storage

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle to sync and install any requested Android SDK components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

This ZIP contains Android source project files, not a precompiled APK. Building requires Android Studio and the Android SDK.
