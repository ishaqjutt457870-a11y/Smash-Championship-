# SMASH CHAMPIONSHIP — Android Studio Project
### Developed By Hassan · HASSAN DEVELOPERS

## Tech Stack
- **Platform**: Modern Android (SDK 26–35)
- **Language**: Kotlin 2.0
- **UI Framework**: Jetpack Compose (Material3)
- **Database**: Room Database (SQLite offline-first)
- **Architecture**: MVVM with Kotlin Coroutines & Flow

## How to Build & Run in Android Studio
1. Unzip this directory.
2. Open **Android Studio Ladybug (or Hedgehog/Iguana/Koala)**.
3. Select **File &rarr; Open** and pick this folder.
4. Let Gradle sync project dependencies.
5. Select an Emulator (e.g. Pixel 8 API 34) or connected device.
6. Click the green **Run (▶)** button.
