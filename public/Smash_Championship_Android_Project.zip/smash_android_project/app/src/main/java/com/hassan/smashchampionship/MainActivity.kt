package com.hassan.smashchampionship

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.hassan.smashchampionship.ui.screens.LoadingScreen
import com.hassan.smashchampionship.ui.screens.ScoreboardScreen

/**
 * SMASH CHAMPIONSHIP
 * Developed By Hassan · HASSAN DEVELOPERS
 * Ultimate Professional Jetpack Compose & Room Database Application
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Official Android SplashScreen API initialization
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        setContent {
            var isLoading by remember { mutableStateOf(true) }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF10B981),
                    secondary = Color(0xFFF59E0B),
                    background = Color(0xFF061A11),
                    surface = Color(0xFF0C291B)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (isLoading) {
                        LoadingScreen(onLoadingFinished = {
                            isLoading = false
                        })
                    } else {
                        ScoreboardScreen()
                    }
                }
            }
        }
    }
}
