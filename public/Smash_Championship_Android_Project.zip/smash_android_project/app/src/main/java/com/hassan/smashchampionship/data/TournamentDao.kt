package com.hassan.smashchampionship.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Developed By Hassan · HASSAN DEVELOPERS
 * Room Data Access Object for Offline Badminton Tournaments
 */
@Dao
interface TournamentDao {
    @Query("SELECT * FROM players ORDER BY matchesWon DESC, pointsScored DESC")
    fun getAllPlayersFlow(): Flow<List<PlayerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerEntity): Long

    @Update
    suspend fun updatePlayer(player: PlayerEntity)

    @Delete
    suspend fun deletePlayer(player: PlayerEntity)

    @Query("SELECT * FROM matches")
    fun getAllMatchesFlow(): Flow<List<MatchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatches(matches: List<MatchEntity>)

    @Update
    suspend fun updateMatch(match: MatchEntity)

    @Query("DELETE FROM matches")
    suspend fun clearAllMatches()
}
