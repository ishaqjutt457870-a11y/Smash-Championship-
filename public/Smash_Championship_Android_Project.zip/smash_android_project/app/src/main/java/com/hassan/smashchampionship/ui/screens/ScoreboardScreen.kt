package com.hassan.smashchampionship.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Developed By Hassan · HASSAN DEVELOPERS
 * Professional 21-Point BWF Badminton Scoreboard with Service Court Tracker
 */
@Composable
fun ScoreboardScreen() {
    var pointsA by remember { mutableStateOf(0) }
    var pointsB by remember { mutableStateOf(0) }
    var setNumber by remember { mutableStateOf(1) }
    var server by remember { mutableStateOf("A") }

    val serverCourt = if ((if (server == "A") pointsA else pointsB) % 2 == 0) "Right Court" else "Left Court"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // App & Developer Header
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "SMASH CHAMPIONSHIP",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
            Text(
                text = "Developed By Hassan · HASSAN DEVELOPERS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFF59E0B)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF104831)
            ) {
                Text(
                    text = "Set  &bull; Server: Player  ()",
                    color = Color(0xFFA7F3D0),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    fontSize = 12.sp
                )
            }
        }

        // Split Scoreboard
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Player A
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(280.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C291B)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Player A", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(
                        text = "",
                        fontSize = 84.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Button(
                        onClick = {
                            pointsA++
                            server = "A"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("+1 Point", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Player B
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(280.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C291B)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Player B", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(
                        text = "",
                        fontSize = 84.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Button(
                        onClick = {
                            pointsB++
                            server = "B"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("+1 Point", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Bottom Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            OutlinedButton(onClick = {
                if (pointsA > 0) pointsA--
                else if (pointsB > 0) pointsB--
            }) {
                Text("Undo Point", color = Color.White)
            }

            Button(
                onClick = {
                    pointsA = 0
                    pointsB = 0
                    setNumber++
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))
            ) {
                Text("Next Set", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
