package com.hassan.smashchampionship.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

/**
 * SMASH CHAMPIONSHIP — Premium Loading & Splash Screen
 * Developed By Hassan · HASSAN DEVELOPERS
 * Features:
 * - Animated badminton shuttlecock bouncing in parabolic curve
 * - Smooth circular progress indicator with live percentage
 * - Failsafe timeout to prevent permanent loading screens
 * - Dark and light mode contrast support
 */
@Composable
fun LoadingScreen(
    onLoadingFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    var progress by remember { mutableFloatStateOf(0.12f) }
    var statusText by remember { mutableStateOf("Connecting Room Database...") }

    // Floating bounce animation for shuttlecock
    val infiniteTransition = rememberInfiniteTransition(label = "ShuttlecockMotion")
    val bounceY by infiniteTransition.animateFloat(
        initialValue = -12f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Bounce"
    )
    val rotation by infiniteTransition.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Rotation"
    )

    // Robust data preloading with error safety timeout
    LaunchedEffect(Unit) {
        withTimeoutOrNull(3500L) {
            try {
                delay(300)
                progress = 0.38f
                statusText = "Loading Player Rosters & Records..."

                delay(400)
                progress = 0.68f
                statusText = "Loading Fixtures & BWF Standings..."

                delay(400)
                progress = 0.92f
                statusText = "Preparing Your Championship..."

                delay(300)
                progress = 1.0f
                statusText = "Championship Ready!"

                delay(200)
            } catch (e: Exception) {
                progress = 1.0f
            }
        }
        onLoadingFinished()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF071C13)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // Animated Shuttlecock Emblem
            Box(
                modifier = Modifier
                    .offset(y = bounceY.dp)
                    .rotate(rotation)
                    .size(96.dp)
                    .background(Color(0xFF104831), RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "🏸",
                    fontSize = 48.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // App Title
            Text(
                text = "SMASH CHAMPIONSHIP",
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.sp
            )

            // Developer Credit
            Text(
                text = "Developed By Hassan",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFF59E0B)
            )

            Text(
                text = "HASSAN DEVELOPERS",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFA7F3D0),
                letterSpacing = 1.2.sp
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Smooth Circular Progress Indicator with Live Percentage
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(72.dp)
            ) {
                CircularProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF59E0B),
                    strokeWidth = 6.dp,
                    trackColor = Color(0xFF0D2E20),
                )
                Text(
                    text = "${(progress * 100).toInt()}%",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Dynamic Status Text
            Text(
                text = statusText,
                color = Color(0xFFA7F3D0),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Skip Button to ensure instant access if desired
            TextButton(onClick = onLoadingFinished) {
                Text(
                    text = "Skip to Dashboard →",
                    color = Color(0xFF6EE7B7),
                    fontSize = 12.sp
                )
            }
        }
    }
}
