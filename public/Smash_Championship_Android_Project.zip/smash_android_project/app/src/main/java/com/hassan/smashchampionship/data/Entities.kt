package com.hassan.smashchampionship.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Developed By Hassan · HASSAN DEVELOPERS
 * Player Entity for Smash Championship Room Database
 */
@Entity(tableName = "players")
data class PlayerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val photoUri: String? = null,
    val playStyle: String = "Aggressive Attacker",
    val hand: String = "Right",
    val matchesPlayed: Int = 0,
    val matchesWon: Int = 0,
    val matchesLost: Int = 0,
    val setsWon: Int = 0,
    val setsLost: Int = 0,
    val pointsScored: Int = 0,
    val pointsConceded: Int = 0
)

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey val id: String, // e.g. "0-1"
    val playerAId: Long,
    val playerBId: Long,
    val winnerId: Long? = null,
    val set1A: Int? = null,
    val set1B: Int? = null,
    val set2A: Int? = null,
    val set2B: Int? = null,
    val set3A: Int? = null,
    val set3B: Int? = null,
    val isCompleted: Boolean = false,
    val courtNumber: Int = 1
)

@Entity(tableName = "tournaments")
data class TournamentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "Smash Championship",
    val dateCreated: Long = System.currentTimeMillis(),
    val matchFormat: String = "bo3",
    val isStarted: Boolean = true,
    val championPlayerId: Long? = null
)
