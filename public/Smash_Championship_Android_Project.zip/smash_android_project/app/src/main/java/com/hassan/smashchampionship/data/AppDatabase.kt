package com.hassan.smashchampionship.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Developed By Hassan · HASSAN DEVELOPERS
 * Room Database Provider for Smash Championship
 */
@Database(
    entities = [PlayerEntity::class, MatchEntity::class, TournamentEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tournamentDao(): TournamentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smash_championship.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
