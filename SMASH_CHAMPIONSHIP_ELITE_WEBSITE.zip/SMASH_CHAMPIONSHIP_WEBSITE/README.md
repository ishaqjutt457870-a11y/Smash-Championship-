# SMASH CHAMPIONSHIP — Elite Website Edition

A premium, responsive badminton tournament scoring website by Hassan Developers.

## Run
Open `index.html` in a modern browser. No installation or server is required.

## Included
- Refined premium dark-first sports UI with light/dark mode
- Responsive dashboard and navigation
- Player and tournament management
- Singles live scoring with best-of-three games, win-by-two and 30-point cap
- Undo last point
- Basic singles round-robin fixture generation
- Local browser storage and JSON backup/restore

## Important limitations
This is a browser website prototype, not a native Android APK. Data stays in the browser on the device. Advanced features such as doubles/team scoring, official service rotation, full knockout progression, cloud sync, push notifications, PDF reports and multi-device umpire control are not implemented in this edition.
